# Cambiando Destinos- Pagina de Astrologia

## Stack
El proyecto está armado con NodeJS por lo cuál corre en un entorno de NGINX.

Se compone por:

 - Armado web en servidor (SSR)

**Keywords**: NodeJS, EJS

## Levantar el proyecto
Para levantar el proyecto local:

 1. Descarga del repo
 2. Instalar módulos en el **/website**

    *npm i* 


#### Levantar Website

Una vez corriendo el servicio, levantar el proyecto **website** con los comandos `node app.js` o `nodemon app.js` en la carpeta **/website**


## Consignas del trabajo

El proyecto cuenta de dos partes:
   

#### Cliente
Cambiando Destinos es una persona que ofrece cursos de distintos tipos como pnl, coaching y tarot.

  #### Pedido

Como cliente está interesado en armar una web en donde muestre sus productos para generar identidad de marca.

  ## Aspectos Técnicos

Diseño de la pagina web  

### Bootstrap

Use Bootstrap para el desarrollo, dada que esta tecnología es conocida por muchos/as desarrolladores/as y nos permite realizar cambios de manera simple.  
