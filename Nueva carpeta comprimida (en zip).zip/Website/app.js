const express = require('express');
const app = express();
const path = require('path');
const Cursos = require('./utils/cursos')
const port = 3000;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('', (req, res) => {
    return res.render('index', {
        Cursos
    })
});
app.get('/contacto', (req, res) => {
     res.render('pages/contacto', {
         title:'Cambiando destinos|contacto'
    })
});
app.get('/libros', (req, res) => {
    res.render('pages/libros', {
        title:'Cambiando destinos|libros'
   })
});
app.get('/astrologia', (req, res) => {
    res.render('pages/astrologia', {
        title:'Cambiando destinos|astrologia'
   })
});

app.listen(port, () => {
    console.log(`Funcionando en http://localhost:${port}`)
});
