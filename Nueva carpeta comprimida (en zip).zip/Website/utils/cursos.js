const Cursos = [
    {
        name: 'Coaching',
        title: 'Aprende COACHING',
        src: "img/coaching-1.jpg",
        text: 'Este curso de COACHING es para VOS!!! Imagina un modo de explorar estas preguntas de la mano que alguien te ayude a realizar tus mejores sueños y a convertirte en esa persona que siempre has deseado ser. ESO ES EL COACHING La Coach Valeria de Liechtenstein, es nuestra Guía en ese camino hacia lo mejor que podemos ser, incrementando tus habilidades, te proporcionara nuevas perspectivas y te ayudara a mejorar tu eficacia, dirección equilibrio. Incluye material de estudio y certificado de asistencia.',
        button: 'Consulta'

    },

    {
        name: 'Pnl',
        title: 'Aprende PNL',
        src: "img/pnl.jpg",
        text: 'COMPLETO Técnicas de Autoayuda y Motivación para levantar la Autoestima y Resolver Conflictos, un aprendizaje Transformacional que te permitirá:Conocerte más a vos mismo y a los demás Aumentar tu confianza personalmejorar los codigos de comunicacion, Reflexionar a cerca de tus creencias en especial las Limitaciones Desarrollar la empatía con los demás Acercarte a tus objetivos tanto personal como familiar o laboral,Flexibilizarte pudiendo hacer, decir, sentir algo diferente a lo que estás acostumbrado y no te servia!!Incluye material de estudio y certificado de asistencia',
        button: 'Consulta'
    },

    {
        name: 'Tarot',
        title: 'Curso de tarot',
        src: "img/tarot1.jpg",
        text: 'En el Curso se aprenderá y practicará: Cuidado de las Cartas. El medio ambiente donde leer las cartas.Como actúan las cartas. Estudio de los Arcanos Mayores y menores. Baraje y corte, Lectura de las Cartas.Combinación del SI o NO. Las doce casas del zodiaco. Tirada Astrológica. Bases de Astrología Alegoría de los 12 signos. Características de los mismos. Todas las Combinaciones y Tiradas del Mismo (cruz celta, tirada del amor, oráculo de la vida, método del tablero, pirámide etc.) Introducción a la numerología con Tarot Egipcio y aplicada ellos.Descomposición del nombre, número de destino, personalidad y Karma. Pináculo (ciclos de 9 años con las cartas.Historia de Egipto. Radiestesia. Péndulo.',
        button: 'Consulta'
    }
]


module.exports = Cursos;